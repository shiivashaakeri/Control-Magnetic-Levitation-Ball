syms s

% Define System
A = [0 1 0;245 -0.0814 24.47; 0 0 -250];
B = [0;0;5];
C = [1 0 0];
D = 0;
poles = eig(A)


t = 0:0.01:10;
u = ones(size(t));
x0 = [0.06 0 0];

%%   1

I=eye(3,3);


c=[B A*B A*A*B];
k_slow=[0 0 1]*c^-1*((A+5*I)*(A+4*I)*(A+4*I))
k_fast=[0 0 1]*c^-1*((A+30*I)*(A+35*I)*(A+45*I))

t = 0:0.01:10;

step(ss(A-B*k_slow,B,C,D),t)
title('Step Response Slow Poles')
% 
% 
% step(ss(A-B*k_fast,B,C,D),t)
% title('Step Response Fast Poles')

t=0:0.001:50;

[y_slow,t]=step(ss(A-B*k_slow,B,C,D),t);
[y_fast,t]=step(ss(A-B*k_fast,B,C,D),t);

p_slow=(-C*(A-B*k_slow)^-1*B)^-1
p_fast=(-C*(A-B*k_fast)^-1*B)^-1

%% 2
I = eye(4,4);
p4 = -7;
p44 = -50;

A_bar = [A zeros(3, 1); -C zeros(1)];
B_bar = [B; 0];
c_bar = [B_bar A_bar*B_bar A_bar*A_bar*B_bar A_bar*A_bar*A_bar*B_bar];

c=[B A*B A*A*B A*A*A*B];


k=[0 0 0 1]*c_bar^-1*((A_bar+5*I)*(A_bar+4*I)*(A_bar+3*I)*(A_bar+7*I));
kb = acker(A_bar, B_bar, [3 4 5 7]);

k1 = k(1:3)
k2 = k(4)

Ac = [A-B*k1 -B*k2; -C 0]
Bc = [zeros(3, 1); 1]
Cc = [C 0]
Dc = 0

t=0:0.001:100;

step(Ac, Bc, Cc, Dc, 1, t), grid

%% 3
poles3=[-5 -6 -7];

L3=place(A',C',poles3);
L3=L3'
A_=A-L3*C

%% 4
F=[-8 0;0 -10];
L_RO=[1;1];

T = lyap(-1*F,A,-1*L_RO*C)

CTinv=[C;T]^-1
