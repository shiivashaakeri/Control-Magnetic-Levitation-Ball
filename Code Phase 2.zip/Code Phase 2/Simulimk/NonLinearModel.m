syms s

% Define System
A = [0 1 0;245 -0.0814 24.47; 0 0 -250];
B = [0;0;5];
C = [1 0 0];
D = 0;

poles=[-10 -15 -20];


%%%%%feedback controller 
k=place(A,B,poles)
p=(-C*(A-B*k)^-1*B)^-1





